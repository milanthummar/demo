package com.java.marineweather.buoy.senddata;

import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.logging.Logger;

@Component
public class InvokeReportRest {

    private RestTemplate rt = new RestTemplate();
    private final String addDataURL = "http://localhost:8080/weather/v1/report";
    private HttpHeaders headers = new HttpHeaders();
    private JSONObject buoyJsonObject;
    private final Integer buoyIdentificationNo = 1234567890;

    private final Logger logger = Logger.getLogger(InvokeReportRest.class.getName());

    public void submitBuoyData(){
        headers.setContentType(MediaType.APPLICATION_JSON);
        buoyJsonObject = new JSONObject();

        buoyJsonObject.put("buoyIdentificationNumber", buoyIdentificationNo);
        buoyJsonObject.put("buoyTemperature", "32.9");
        buoyJsonObject.put("windSpeed", "15");
        buoyJsonObject.put("windDirection", "SW");

        HttpEntity<String> request = new HttpEntity<>(buoyJsonObject.toString(), headers);

        String response = rt.postForObject(addDataURL, request, String.class);

        logger.info("Response after submitting: "+ response);
    }
}
