package com.java.marineweather.buoy.scheduler;

import com.java.marineweather.buoy.senddata.InvokeReportRest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class BuoyScheduler {

    private InvokeReportRest invokeReportRest;

    private BuoyScheduler(InvokeReportRest invokeReportRest){
        this.invokeReportRest = invokeReportRest;
    }

    @Scheduled(fixedRate = 5000)
    public void submitBuoyData(){
        invokeReportRest.submitBuoyData();
    }

}
