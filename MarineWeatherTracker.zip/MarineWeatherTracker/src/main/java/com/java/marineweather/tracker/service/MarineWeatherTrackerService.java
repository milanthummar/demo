package com.java.marineweather.tracker.service;

import com.java.marineweather.tracker.dao.MarineWeatherTrackerDao;
import com.java.marineweather.tracker.pojo.BuoyData;
import org.springframework.stereotype.Service;

@Service
public class MarineWeatherTrackerService {

    private MarineWeatherTrackerDao marineWeatherTrackerDao;

    public MarineWeatherTrackerService(MarineWeatherTrackerDao marineWeatherTrackerDao){
        this.marineWeatherTrackerDao = marineWeatherTrackerDao;
    }

    public boolean addMarineWeatherData(BuoyData buoyData){
       return marineWeatherTrackerDao.addMarineWeatherData(buoyData);
    }

}
