package com.java.marineweather.buoy.scheduler.listener;

import com.java.marineweather.buoy.senddata.InvokeReportRest;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.logging.Logger;

@Component
public class BuoyListener {

    private InvokeReportRest invokeReportRest;
    private final Logger logger = Logger.getLogger(BuoyListener.class.getName());

    public BuoyListener(InvokeReportRest invokeReportRest){
        this.invokeReportRest = invokeReportRest;
    }

    @KafkaListener(id = "weather-stations", topics = "eu_buoy")
    public void listenForEu_Buoy(String message){
        logger.info("Received message: "+message);

        invokeReportRest.submitBuoyData();
    }
}
