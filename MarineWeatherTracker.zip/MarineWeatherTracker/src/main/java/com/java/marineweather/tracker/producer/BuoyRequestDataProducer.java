package com.java.marineweather.tracker.producer;

import com.java.marineweather.tracker.station.mapper.WeatherStationMapper;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

@Component
public class BuoyRequestDataProducer {

    private KafkaTemplate<String, String> kafkaTemplate;
    private final Logger logger = Logger.getLogger(BuoyRequestDataProducer.class.getName());

    public BuoyRequestDataProducer(KafkaTemplate<String, String> kafkaTemplate){
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendRequestToBuoy(String buoyId){

        String topicName = WeatherStationMapper.getInstance().getStationName(Integer.parseInt(buoyId));
        logger.info("Sending Message to Kafka Listener for topic"+ topicName);
        kafkaTemplate.send(topicName, UUID.randomUUID().toString(),"Requesting Buoy Data");
    }
}
