package com.java.marineweather.tracker.controller;

import com.java.marineweather.tracker.pojo.BuoyData;
import com.java.marineweather.tracker.producer.BuoyRequestDataProducer;
import com.java.marineweather.tracker.service.MarineWeatherTrackerService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value ="/weather/v1")
public class MarineWeatherTrackerController {

    private MarineWeatherTrackerService marineWeatherTrackerService;
    private BuoyRequestDataProducer buoyRequestDataProducer;

    public MarineWeatherTrackerController(MarineWeatherTrackerService marineWeatherTrackerService, BuoyRequestDataProducer buoyRequestDataProducer){
        this.marineWeatherTrackerService = marineWeatherTrackerService;
        this.buoyRequestDataProducer = buoyRequestDataProducer;
    }


    @PostMapping("/report")
    @ResponseStatus(HttpStatus.CREATED)
    public @ResponseBody String addMarineWeatherData(@RequestBody BuoyData buoyData){
        marineWeatherTrackerService.addMarineWeatherData(buoyData);

        return "Data has been Submitted for " + buoyData.getBuoyIdentificationNumber();
    }

    @PostMapping("/request/{buoyId}")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public @ResponseBody String requestBuoyToSendData(@PathVariable String buoyId) {
        buoyRequestDataProducer.sendRequestToBuoy(buoyId);
        return "Request has been send to buoy";
    }
}
