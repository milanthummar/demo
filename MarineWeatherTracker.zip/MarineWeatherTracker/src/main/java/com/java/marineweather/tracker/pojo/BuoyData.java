package com.java.marineweather.tracker.pojo;

public class BuoyData {
    private Integer buoyIdentificationNumber;
    private Double buoyTemperature;
    private Double windSpeed;
    private String windDirection;

    public Integer getBuoyIdentificationNumber() {
        return buoyIdentificationNumber;
    }

    public void setBuoyIdentificationNumber(Integer buoyIdentificationNumber) {
        this.buoyIdentificationNumber = buoyIdentificationNumber;
    }

    public Double getBuoyTemperature() {
        return buoyTemperature;
    }

    public void setBuoyTemperature(Double buoyTemperature) {
        this.buoyTemperature = buoyTemperature;
    }

    public Double getWindSpeed() {
        return windSpeed;
    }

    public void setWindSpeed(Double windSpeed) {
        this.windSpeed = windSpeed;
    }

    public String getWindDirection() {
        return windDirection;
    }

    public void setWindDirection(String windDirection) {
        this.windDirection = windDirection;
    }
}
