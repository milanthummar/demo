package com.java.marineweather.tracker.station.mapper;

import java.util.HashMap;
import java.util.Map;

public class WeatherStationMapper {


    private static WeatherStationMapper weatherStationMapper;
    private final Map<Integer, String> mapper = new HashMap<>();
    private WeatherStationMapper(){
        this.mapper.put(1234567890, "eu_buoy");
    }

    public String getStationName(Integer buoyIdentificationNumber){
        return mapper.get(buoyIdentificationNumber);
    }

    public static WeatherStationMapper getInstance(){

        if(weatherStationMapper == null){
            weatherStationMapper = new WeatherStationMapper();
        }
        return weatherStationMapper;
    }
}
