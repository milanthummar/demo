package com.java.marineweather.tracker.dao;

import com.java.marineweather.tracker.pojo.BuoyData;
import org.springframework.stereotype.Component;

import java.util.logging.Logger;

@Component
public class MarineWeatherTrackerDao {

    private final Logger logger = Logger.getLogger(MarineWeatherTrackerDao.class.getName());

    public boolean addMarineWeatherData(BuoyData buoyData){
       logger.info("Marine Data has been added for: "+ buoyData.getBuoyIdentificationNumber());
        return true;
    }

}
